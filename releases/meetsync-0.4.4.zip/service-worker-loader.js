import './assets/service-worker.ts-aY5VU1IF.js';
