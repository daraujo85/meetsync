import './assets/service-worker.ts-DEMOQJPz.js';
