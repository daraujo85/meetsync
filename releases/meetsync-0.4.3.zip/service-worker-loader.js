import './assets/service-worker.ts-BWlvDKpX.js';
