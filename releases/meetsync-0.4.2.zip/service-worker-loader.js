import './assets/service-worker.ts-8-x2M8fQ.js';
