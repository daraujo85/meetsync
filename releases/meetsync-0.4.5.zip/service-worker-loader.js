import './assets/service-worker.ts-BgiIkH2C.js';
